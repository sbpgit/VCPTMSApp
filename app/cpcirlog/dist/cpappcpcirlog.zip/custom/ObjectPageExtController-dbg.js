sap.ui.define([],
function (){
    "use strict";
    return {
        onHelpPress: function(oEvent) {
            alert('onHelpPress');
        }
    };
});
