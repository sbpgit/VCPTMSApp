sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("cfgapp.varstr.cfgapp_varstruc.controller.App", {

		onInit : function () {
			// apply content density mode to root view
		}
	});

});