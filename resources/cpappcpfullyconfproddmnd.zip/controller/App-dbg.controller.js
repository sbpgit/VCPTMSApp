sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("cpapp.cpfullyconfproddmnd.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  